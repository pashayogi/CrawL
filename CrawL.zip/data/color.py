# Manual Color

W = '\033[1;37m' 
N = '\033[0m'
R = '\033[31m'
B = '\033[1;37m\033[34m' 
G = '\033[1;32m'
O = '\033[33m'
C = '\033[36m'
notice  = "{}{}[*]{} ".format(N,B,N)
warning = "{}[-]{} ".format(R,N)
good    = "{}[!]{} ".format(G,N)
warn    = "{}[!]{} ".format(O,N)
